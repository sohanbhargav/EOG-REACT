import { reducer as weatherReducer } from '../Features/Weather/reducer';

export default {
  weather: weatherReducer,
};
